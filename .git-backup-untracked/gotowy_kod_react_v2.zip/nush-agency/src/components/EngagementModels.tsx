import { motion } from 'motion/react';
import { ArrowUpRight, Compass, Layers3, UsersRound } from 'lucide-react';

const models = [
  { num: '01', title: 'Diagnoza i roadmapa', icon: Compass, forWho: 'Gdy potrzebujesz jasnego kierunku', scope: 'Analiza danych, procesów i kanałów sprzedaży', result: 'Priorytety oraz plan wdrożenia' },
  { num: '02', title: 'Sprint wdrożeniowy', icon: Layers3, forWho: 'Gdy znasz problem i chcesz ruszyć', scope: 'Jeden konkretny obszar, zespół i termin', result: 'Działające rozwiązanie, nie prezentacja' },
  { num: '03', title: 'Stały zespół wzrostu', icon: UsersRound, forWho: 'Gdy system ma rosnąć razem z firmą', scope: 'Ciągłe testy, optymalizacja i rozwój', result: 'Partner do długofalowego wzrostu' },
];

export default function EngagementModels() {
  return <section id="wspolpraca" className="border-b border-white/10 bg-[#080808] px-6 py-24 md:px-10"><div className="mx-auto max-w-7xl"><p className="mb-5 font-mono text-xs font-bold uppercase tracking-widest text-neon">[03] JAK MOŻEMY ZACZĄĆ</p><h2 className="max-w-4xl text-4xl font-black uppercase leading-[1.1] tracking-tight md:text-6xl break-words lg:pr-12">Konkretny problem. Konkretny model współpracy.</h2><div className="mt-12 grid gap-4 lg:grid-cols-3">{models.map((model, i) => { const Icon = model.icon; return <motion.article key={model.num} initial={{ opacity: 0, y: 25 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * .1 }} whileHover={{ y: -8 }} className="group border border-white/10 p-6 hover:border-neon/70 transition-colors"><div className="flex justify-between"><span className="font-mono text-3xl text-neon">{model.num}</span><Icon className="text-white/50 group-hover:text-neon transition-colors" /></div><h3 className="mt-14 text-xl font-black uppercase leading-snug">{model.title}</h3><p className="mt-5 text-sm text-neon">{model.forWho}</p><div className="mt-6 border-t border-white/10 pt-4 text-sm text-white/60 leading-relaxed"><p>{model.scope}</p><p className="mt-3 text-white leading-relaxed">{model.result}</p></div><a href="#kontakt" className="mt-8 inline-flex items-center gap-2 font-mono text-xs uppercase tracking-wider text-white/70 group-hover:text-neon">Porozmawiajmy <ArrowUpRight size={15} /></a></motion.article> })}</div></div></section>;
}
